"""HACS Data script."""
