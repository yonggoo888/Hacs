# Default repositories

This is where HACS gets its default repositories from to show in the "store".

If you want to publish your repositories as default in HACS have a look here:

- https://hacs.xyz/docs/publish/start
- https://hacs.xyz/docs/publish/include
