---
name: flag
about: Flagging of content shown
title: ''
labels: flag
assignees: ludeeus
---

<!-- Learn how to submit an issue here https://hacs.xyz/docs/issues -->
## Describe why you are flagging this

_This template should **only** be used if a repository **needs** to be removed/blacklisted from HACS_