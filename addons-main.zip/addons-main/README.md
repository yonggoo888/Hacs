# HACS Add-ons Repository

This repository contains the source code for the HACS add-ons.

## Add-ons

- [**get**: _The easiest way to get HACS for Home Assistant._](./get)
