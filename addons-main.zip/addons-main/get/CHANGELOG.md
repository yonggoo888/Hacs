# 1.3.1

- Fix problems with getting the current version for development builds

# 1.3.0

- Dynamically get the version again

# 1.2.1

- Create custom_components directory if it does not exist

# 1.2.0

- Set dev version to 2.0.0

# 1.1.1

- Fix version format for development build

# 1.1.0

- Added option to get development builds
- Change base images to `*-base-python:3.12-alpine3.20`

# 1.0.0

Initial release
